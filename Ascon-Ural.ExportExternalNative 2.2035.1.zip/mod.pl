print "parsing ".$ARGV[0];
open f1,"<$ARGV[0].il";
open f2,">$ARGV[0].il2";
while($s=<f1>)
{
  if($s=~/\/\/ llExport/)
  {
    $s .= ".export[".$export++."]\r\n";
  }
  print f2 $s;
}